CREATE PROCEDURE insert_row(IN id INT, IN name VARCHAR(20), IN age INT)
  BEGIN
INSERT INTO emp VALUES(id, name, age);
END;
