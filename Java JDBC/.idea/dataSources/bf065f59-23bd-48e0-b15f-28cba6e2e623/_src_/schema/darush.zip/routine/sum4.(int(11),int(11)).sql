CREATE FUNCTION sum4(num1 INT, num2 INT)
  RETURNS INT
  begin
DECLARE temp int(8);
SET temp=num1+num2;
return temp;
end;
